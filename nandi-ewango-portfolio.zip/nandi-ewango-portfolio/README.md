# Nandi Ewango, AI portfolio

AI Product Lead and Senior AI Consultant. AI agents, assistants and their architectures, built for Orange Business and TF1.

- Portfolio: `index.html` (single self-contained page)
- PDF version: `Nandi-Ewango-AI-Portfolio.pdf`
- LinkedIn: https://www.linkedin.com/in/nandi-ewango/

Static site with no build step. It can be served by GitHub Pages (deploy from the `main` branch, root folder) or by Netlify.

Built with Claude.
